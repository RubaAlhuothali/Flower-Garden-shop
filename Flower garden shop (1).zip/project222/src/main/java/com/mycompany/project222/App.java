package com.mycompany.project222;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.regex.Pattern;
import javafx.animation.PauseTransition;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

/**
 * JavaFX App
 */
public class App extends Application {

    double totalPrice,totalShip, totalTax,total0 = 0.0;
    ShoppingCart item;
    VBox cartItemList = new VBox();
    private TextField cardNumberTextField;
    private TextField expirationDateTextField;
    private TextField amountTextField;
    
    Text priceText = new Text("Price:- $" + totalPrice);
        Text shipmentText = new Text("Shipment:- $" + totalShip);
        Text taxText = new Text("Tax:- $" + totalTax);
        Text totalText = new Text("Total:- $" + total0);
        
    Label flowerLabel; 
    private RadioButton rbCredit;
    private RadioButton rbCash;
    
    public Scene confScene,homePage,cartScene,logIn, flowerListScene,signUpScene,calla,
    poppy,Orchid,Lily,Iris,Flax,Daisy,daffodil,payScene;
    Button confirm = new Button("Confirm");
    
    private List<ShoppingCart> shoppingCart = new ArrayList<>();
    private ObservableList<User> userDatabase = FXCollections.observableArrayList();
    private List<ShoppingCart> cartItems = getShoppingCartItems();

   private boolean authenticateUser(String username, String password) {
    return userDatabase.stream().anyMatch(user -> user.getUsername().equals(username) && user.getPassword().equals(password));
}

    private boolean registerUser(String username, String password, String firstName, String lastName,
                              String userEmail, String userPhoneNumber) {
    if (!userDatabase.stream().anyMatch(user -> user.getUsername().equals(username))) {
        User newUser = new User(username, password, firstName, lastName, userEmail, userPhoneNumber);
        userDatabase.add(newUser);
        return true;
    }
    return false; // User with the same username already exists
}

    
    
    @Override
    public void start(Stage primaryStage) {
   
        GridPane pane = new GridPane();  
        pane.setHgap(0);
        pane.setVgap(5);
        HBox p1 = new HBox(20);
        Circle c1 = new Circle();
        c1.setFill(Color.WHITE);
        c1.setCenterX(90); 
        c1.setCenterY(300);
        c1.setRadius(70);
        p1.setAlignment(Pos.TOP_CENTER);
        Image l=new Image("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT2cCq6zKhvaV2u5fP07uVphRJbs8fTLxIwTA&usqp=CAU");
        c1.setFill(new ImagePattern(l));//to put the pic in the circle
        c1.setStroke(Color.LIGHTBLUE);
        c1.setStrokeWidth(3);
        p1.getChildren().addAll(c1); p1.setAlignment(Pos.TOP_CENTER); BorderPane pane1 = new BorderPane(); pane1.setTop(p1);

        VBox p2 = new VBox(10);//username and password textfiled
        TextField UName; 
        TextField pass;
        Label l1 = new Label("User name: "); l1.setMinWidth(150); l1.setAlignment(Pos.BOTTOM_LEFT);
        l1.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));
        UName = new TextField(); UName.setMinWidth(200); UName.setMaxWidth(200); 
        Label l2 = new Label("Password:"); l2.setMinWidth(100); l2.setAlignment(Pos.BOTTOM_LEFT);
        l2.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));
        pass = new TextField(); pass.setMinWidth(200); pass.setMaxWidth(200);
       

        p2.getChildren().addAll(l1,UName,l2,pass);
        p2.setAlignment(Pos.CENTER_LEFT); 
        BorderPane pane2 = new BorderPane(); 
        pane2.setTop(p2);

        Text t2 = new Text("\n \n  \n ");//to bring the pic a lil lower in the screen

        VBox p3 = new VBox(10);//log n button
        Button bt1 = new Button("           LOG IN           ");
        bt1.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));
        bt1.setStyle("-fx-background-color: #64CCC5");
        bt1.setAlignment(Pos.BOTTOM_RIGHT);
        Button bt2 = new Button("           Sign-Up           ");
        bt2.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));
        bt2.setStyle("-fx-background-color: #64CCC5");
        p3.getChildren().addAll(bt1,bt2); p3.setAlignment(Pos.CENTER); 
        BorderPane pane3 = new BorderPane(); pane3.setTop(p3);

        pane.setStyle("-fx-background-color: #DAFFFB");
        
        //adding to the screen
        pane.add(t2,1,0);
        pane.add(p1,1,1);
        pane.add(p2,1,2);
        pane.add(p3,1,4);
        pane.setAlignment(Pos.TOP_CENTER); 

        logIn = new Scene(pane,600,600);
        
        bt1.setOnAction(e ->{
            String username = UName.getText();
            String password = pass.getText();


     Label errorMessageLabel = new Label();
    errorMessageLabel.setTextFill(Color.RED);
    pane.add(errorMessageLabel, 1, 3);

    if (username.isEmpty() || password.isEmpty()) {
        errorMessageLabel.setText("Please fill in all required fields.");
    } else {
        // Perform user registration logic using the FlowerApp instance
        boolean isAuthenticated = authenticateUser(username, password);

            if (isAuthenticated) {
                // Navigate to the login scene after successful registration
                primaryStage.setScene(flowerListScene(primaryStage)); 
            } else {
                // Display an error message or handle unsuccessful registration
                errorMessageLabel.setText("User registration failed. Please try again.");
            }
    }
        });
        
        bt2.setOnAction(e->{
           primaryStage.setScene(signUpScene(primaryStage)); 
        });

        primaryStage.setTitle("Flower Little Shop"); //Setting the title to Stage.
        primaryStage.setScene(logIn); //Adding the scene to Stage
        primaryStage.show();
 
    }
    
    

    public Scene callaScene(Stage primaryStage){
        
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(10));
        
        
        root.setStyle("-fx-background-color:#AAD7D9;");

        
        VBox leftPane = new VBox(10);
        leftPane.setPadding(new Insets(10));

       
        Rectangle square = new Rectangle(250, 250); 
        String filePath = "C:\\Users\\jack frost\\Downloads\\advanceProject\\flowers (2)\\flowers\\calla.jpeg";
        File file = new File(filePath);
        Image image = new Image(file.toURI().toString());
        square.setFill(new ImagePattern(image));
        square.setStroke(Color.web("#92C7CF"));
        square.setStrokeWidth(3); 

        
        Label price = new Label("Price:$5 ");
        price.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        price.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        price.setStyle("-fx-font-size: 20px; -fx-text-fill: black; -fx-background-color: white;");
        price.setWrapText(true); 
        price.setMaxWidth(200); 
        
       

        Button addToCartButton = new Button("Add to Cart");
        addToCartButton.setPrefWidth(160); 
        addToCartButton.setPrefHeight(40); 
        addToCartButton.setStyle("-fx-font-size: 20px;");
        addToCartButton.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        addToCartButton.setWrapText(true); 
        addToCartButton.setMaxWidth(200); 
        
        leftPane.getChildren().addAll(square, price, addToCartButton);
        
        addToCartButton.setOnAction(e -> addToCart(new Flower("Calla", 5.0)));
        
        
        VBox rightPane = new VBox(10);
        rightPane.setPadding(new Insets(10));

        Label name = new Label("Calla");
        name.setPadding(new Insets(5, 5, 5, 75)); // Insets: top, right, bottom, left
        name.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        name.setStyle("-fx-font-size: 20px; -fx-text-fill: black; -fx-background-color: white;");
        name.setWrapText(true); 
        name.setMaxWidth(200);
        
        
        
        Label description = new Label("Its charming, funnel-shaped blooms are actually spathes that curl around the"
                + " yellow spadix, and may be pink, rose, lavender or violet.");
        description.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        description.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        description.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        description.setWrapText(true); 
        description.setMaxWidth(200); 
        
        
        
        
        Label growth = new Label("Growth period:\n4-6 weeks");
        growth.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        growth.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        growth.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        growth.setWrapText(true); 
        growth.setMaxWidth(200); 
        
        
        
        Label season= new Label("Growing season:\nSpring to Summer");
        season.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        season.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        season.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        season.setWrapText(true); 
        season.setMaxWidth(200); 

        Button returnButton = new Button("Back");
        returnButton.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        returnButton .setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        returnButton.setStyle("-fx-font-size: 20px;"); 
        returnButton.setWrapText(true); 
        returnButton.setMaxWidth(200); 
       
        

        rightPane.getChildren().addAll(name, description, growth, season, returnButton);

        
        root.setLeft(leftPane);
        root.setRight(rightPane);

       
        returnButton.setOnAction(e -> {
 
            primaryStage.setScene(flowerListScene(primaryStage));
            
        });

        calla = new Scene(root, 600, 600);
        
        return calla;
    }
    
    
    public Scene poppyScene(Stage primaryStage){
        
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(10));
        
        
        root.setStyle("-fx-background-color:#AAD7D9;");

        
        VBox leftPane = new VBox(10);
        leftPane.setPadding(new Insets(10));

       
        Rectangle square = new Rectangle(250, 250); 
        String filePath = "C:\\Users\\jack frost\\Downloads\\advanceProject\\flowers (2)\\flowers\\poppy.jpeg";
        File file = new File(filePath);
        Image image = new Image(file.toURI().toString());
        square.setFill(new ImagePattern(image));
        square.setStroke(Color.web("#92C7CF"));
        square.setStrokeWidth(3); 

        
        Label price = new Label("Price:$5 ");
        price.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        price.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        price.setStyle("-fx-font-size: 20px; -fx-text-fill: black; -fx-background-color: white;");
        price.setWrapText(true); 
        price.setMaxWidth(200); 
        
       

        Button addToCartButton = new Button("Add to Cart");
        addToCartButton.setPrefWidth(160); 
        addToCartButton.setPrefHeight(40); 
        addToCartButton.setStyle("-fx-font-size: 20px;");
        addToCartButton.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        addToCartButton.setWrapText(true); 
        addToCartButton.setMaxWidth(200); 
        
        leftPane.getChildren().addAll(square, price, addToCartButton);
        
        addToCartButton.setOnAction(e -> addToCart(new Flower("Poppy", 5.0)));
        
        
        VBox rightPane = new VBox(10);
        rightPane.setPadding(new Insets(10));

        Label name = new Label("Poppy");
        name.setPadding(new Insets(5, 5, 5, 75)); // Insets: top, right, bottom, left
        name.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        name.setStyle("-fx-font-size: 20px; -fx-text-fill: black; -fx-background-color: white;");
        name.setWrapText(true); 
        name.setMaxWidth(200);
        
        
        
        Label description = new Label("Red poppy flowers represent consolation, remembrance and death.");
        description.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        description.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        description.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        description.setWrapText(true); 
        description.setMaxWidth(200); 
        
        
        
        
        Label growth = new Label("Growth period:\n80 to 90 days");
        growth.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        growth.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        growth.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        growth.setWrapText(true); 
        growth.setMaxWidth(200); 
        
        
        
        Label season= new Label("Growing season:\nlate spring to early summer");
        season.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        season.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        season.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        season.setWrapText(true); 
        season.setMaxWidth(200); 

        Button returnButton = new Button("Back");
        returnButton.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        returnButton .setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        returnButton.setStyle("-fx-font-size: 20px;"); 
        returnButton.setWrapText(true); 
        returnButton.setMaxWidth(200); 
       
        

        rightPane.getChildren().addAll(name, description, growth, season, returnButton);

        
        root.setLeft(leftPane);
        root.setRight(rightPane);

       
        returnButton.setOnAction(e -> {
 
            primaryStage.setScene(flowerListScene(primaryStage));
            
        });

        poppy = new Scene(root, 600, 600);
        
        return poppy;
    }
    
    public Scene OrchidScene(Stage primaryStage){
        
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(10));
        
        
        root.setStyle("-fx-background-color:#AAD7D9;");

        
        VBox leftPane = new VBox(10);
        leftPane.setPadding(new Insets(10));

       
        Rectangle square = new Rectangle(250, 250); 
        String filePath = "C:\\Users\\jack frost\\Downloads\\advanceProject\\flowers (2)\\flowers\\orchid.jpeg";
        File file = new File(filePath);
        Image image = new Image(file.toURI().toString());
        square.setFill(new ImagePattern(image));
        square.setStroke(Color.web("#92C7CF"));
        square.setStrokeWidth(3); 

        
        Label price = new Label("Price:$5 ");
        price.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        price.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        price.setStyle("-fx-font-size: 20px; -fx-text-fill: black; -fx-background-color: white;");
        price.setWrapText(true); 
        price.setMaxWidth(200); 
        
       

        Button addToCartButton = new Button("Add to Cart");
        addToCartButton.setPrefWidth(160); 
        addToCartButton.setPrefHeight(40); 
        addToCartButton.setStyle("-fx-font-size: 20px;");
        addToCartButton.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        addToCartButton.setWrapText(true); 
        addToCartButton.setMaxWidth(200); 
        
        leftPane.getChildren().addAll(square, price, addToCartButton);
        
        addToCartButton.setOnAction(e -> addToCart(new Flower("Orchid", 5.0)));
        
        
        VBox rightPane = new VBox(10);
        rightPane.setPadding(new Insets(10));

        Label name = new Label("Calla");
        name.setPadding(new Insets(5, 5, 5, 75)); // Insets: top, right, bottom, left
        name.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        name.setStyle("-fx-font-size: 20px; -fx-text-fill: black; -fx-background-color: white;");
        name.setWrapText(true); 
        name.setMaxWidth(200);
        
        
        
        Label description = new Label("The flower symbolism associated with the orchid is love, beauty, refinement, "
                + "many children, thoughtfulness and mature charm.");
        description.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        description.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        description.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        description.setWrapText(true); 
        description.setMaxWidth(200); 
        
        
        
        
        Label growth = new Label("Growth period:\n2 to 3 months");
        growth.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        growth.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        growth.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        growth.setWrapText(true); 
        growth.setMaxWidth(200); 
        
        
        
        Label season= new Label("Growing season:\nsummer and early fall");
        season.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        season.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        season.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        season.setWrapText(true); 
        season.setMaxWidth(200); 

        Button returnButton = new Button("Back");
        returnButton.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        returnButton .setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        returnButton.setStyle("-fx-font-size: 20px;"); 
        returnButton.setWrapText(true); 
        returnButton.setMaxWidth(200); 
       
        

        rightPane.getChildren().addAll(name, description, growth, season, returnButton);

        
        root.setLeft(leftPane);
        root.setRight(rightPane);

       
        returnButton.setOnAction(e -> {
 
            primaryStage.setScene(flowerListScene(primaryStage));
            
        });

        Orchid = new Scene(root, 600, 600);
        
        return Orchid;
    }
    
    
    public Scene LilyScene(Stage primaryStage){
        
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(10));
        
        
        root.setStyle("-fx-background-color:#AAD7D9;");

        
        VBox leftPane = new VBox(10);
        leftPane.setPadding(new Insets(10));

       
        Rectangle square = new Rectangle(250, 250); 
        String filePath = "C:\\Users\\jack frost\\Downloads\\advanceProject\\flowers (2)\\flowers\\lily.jpeg";
        File file = new File(filePath);
        Image image = new Image(file.toURI().toString());
        square.setFill(new ImagePattern(image));
        square.setStroke(Color.web("#92C7CF"));
        square.setStrokeWidth(3); 

        
        Label price = new Label("Price:$5 ");
        price.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        price.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        price.setStyle("-fx-font-size: 20px; -fx-text-fill: black; -fx-background-color: white;");
        price.setWrapText(true); 
        price.setMaxWidth(200); 
        
       

        Button addToCartButton = new Button("Add to Cart");
        addToCartButton.setPrefWidth(160); 
        addToCartButton.setPrefHeight(40); 
        addToCartButton.setStyle("-fx-font-size: 20px;");
        addToCartButton.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        addToCartButton.setWrapText(true); 
        addToCartButton.setMaxWidth(200); 
        
        leftPane.getChildren().addAll(square, price, addToCartButton);
        
        addToCartButton.setOnAction(e -> addToCart(new Flower("Lily", 5.0)));
        
        
        VBox rightPane = new VBox(10);
        rightPane.setPadding(new Insets(10));

        Label name = new Label("Lily");
        name.setPadding(new Insets(5, 5, 5, 75)); // Insets: top, right, bottom, left
        name.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        name.setStyle("-fx-font-size: 20px; -fx-text-fill: black; -fx-background-color: white;");
        name.setWrapText(true); 
        name.setMaxWidth(200);
        
        
        
        Label description = new Label("The flowers represent purity, innocence.");
        description.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        description.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        description.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        description.setWrapText(true); 
        description.setMaxWidth(200); 
        
        
        
        
        Label growth = new Label("Growth period:\n30-120 days");
        growth.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        growth.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        growth.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        growth.setWrapText(true); 
        growth.setMaxWidth(200); 
        
        
        
        Label season= new Label("Growing season:\nearly summer to late summer");
        season.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        season.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        season.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        season.setWrapText(true); 
        season.setMaxWidth(200); 

        Button returnButton = new Button("Back");
        returnButton.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        returnButton .setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        returnButton.setStyle("-fx-font-size: 20px;"); 
        returnButton.setWrapText(true); 
        returnButton.setMaxWidth(200); 
       
        

        rightPane.getChildren().addAll(name, description, growth, season, returnButton);

        
        root.setLeft(leftPane);
        root.setRight(rightPane);

       
        returnButton.setOnAction(e -> {
 
            primaryStage.setScene(flowerListScene(primaryStage));
            
        });

        Lily = new Scene(root, 600, 600);
        
        return Lily;
    }
    
    public Scene IrisScene(Stage primaryStage){
        
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(10));
        
        
        root.setStyle("-fx-background-color:#AAD7D9;");

        
        VBox leftPane = new VBox(10);
        leftPane.setPadding(new Insets(10));

       
        Rectangle square = new Rectangle(250, 250); 
        String filePath = "C:\\Users\\jack frost\\Downloads\\advanceProject\\flowers (2)\\flowers\\IRISjpeg.jpeg";
        File file = new File(filePath);
        Image image = new Image(file.toURI().toString());
        square.setFill(new ImagePattern(image));
        square.setStroke(Color.web("#92C7CF"));
        square.setStrokeWidth(3); 

        
        Label price = new Label("Price:$5 ");
        price.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        price.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        price.setStyle("-fx-font-size: 20px; -fx-text-fill: black; -fx-background-color: white;");
        price.setWrapText(true); 
        price.setMaxWidth(200); 
        
       

        Button addToCartButton = new Button("Add to Cart");
        addToCartButton.setPrefWidth(160); 
        addToCartButton.setPrefHeight(40); 
        addToCartButton.setStyle("-fx-font-size: 20px;");
        addToCartButton.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        addToCartButton.setWrapText(true); 
        addToCartButton.setMaxWidth(200); 
        
        leftPane.getChildren().addAll(square, price, addToCartButton);
        
        addToCartButton.setOnAction(e -> addToCart(new Flower("Calla", 5.0)));
        
        
        VBox rightPane = new VBox(10);
        rightPane.setPadding(new Insets(10));

        Label name = new Label("Iris");
        name.setPadding(new Insets(5, 5, 5, 75)); // Insets: top, right, bottom, left
        name.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        name.setStyle("-fx-font-size: 20px; -fx-text-fill: black; -fx-background-color: white;");
        name.setWrapText(true); 
        name.setMaxWidth(200);
        
        
        
        Label description = new Label("They can represent faith, hope, courage, wisdom and admiration.");
        description.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        description.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        description.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        description.setWrapText(true); 
        description.setMaxWidth(200); 
        
        
        
        
        Label growth = new Label("Growth period:\n6 to 8 weeks");
        growth.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        growth.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        growth.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        growth.setWrapText(true); 
        growth.setMaxWidth(200); 
        
        
        
        Label season= new Label("Growing season:\nlate spring to early summer");
        season.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        season.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        season.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        season.setWrapText(true); 
        season.setMaxWidth(200); 

        Button returnButton = new Button("Back");
        returnButton.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        returnButton .setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        returnButton.setStyle("-fx-font-size: 20px;"); 
        returnButton.setWrapText(true); 
        returnButton.setMaxWidth(200); 
       
        

        rightPane.getChildren().addAll(name, description, growth, season, returnButton);

        
        root.setLeft(leftPane);
        root.setRight(rightPane);

       
        returnButton.setOnAction(e -> {
 
            primaryStage.setScene(flowerListScene(primaryStage));
            
        });

        Iris = new Scene(root, 600, 600);
        
        return Iris;
    }
    
    public Scene FlaxScene(Stage primaryStage){
        
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(10));
        
        
        root.setStyle("-fx-background-color:#AAD7D9;");

        
        VBox leftPane = new VBox(10);
        leftPane.setPadding(new Insets(10));

       
        Rectangle square = new Rectangle(250, 250); 
        String filePath = "C:\\Users\\jack frost\\Downloads\\advanceProject\\flowers (2)\\flowers\\flax.jpeg";
        File file = new File(filePath);
        Image image = new Image(file.toURI().toString());
        square.setFill(new ImagePattern(image));
        square.setStroke(Color.web("#92C7CF"));
        square.setStrokeWidth(3); 

        
        Label price = new Label("Price:$5 ");
        price.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        price.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        price.setStyle("-fx-font-size: 20px; -fx-text-fill: black; -fx-background-color: white;");
        price.setWrapText(true); 
        price.setMaxWidth(200); 
        
       

        Button addToCartButton = new Button("Add to Cart");
        addToCartButton.setPrefWidth(160); 
        addToCartButton.setPrefHeight(40); 
        addToCartButton.setStyle("-fx-font-size: 20px;");
        addToCartButton.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        addToCartButton.setWrapText(true); 
        addToCartButton.setMaxWidth(200); 
        
        leftPane.getChildren().addAll(square, price, addToCartButton);
        
        addToCartButton.setOnAction(e -> addToCart(new Flower("Flax", 5.0)));
        
        
        VBox rightPane = new VBox(10);
        rightPane.setPadding(new Insets(10));

        Label name = new Label("Calla");
        name.setPadding(new Insets(5, 5, 5, 75)); // Insets: top, right, bottom, left
        name.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        name.setStyle("-fx-font-size: 20px; -fx-text-fill: black; -fx-background-color: white;");
        name.setWrapText(true); 
        name.setMaxWidth(200);
        
        
        
        Label description = new Label("symbolic of domestication.");
        description.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        description.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        description.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        description.setWrapText(true); 
        description.setMaxWidth(200); 
        
        
        
        
        Label growth = new Label("Growth period:\n45 to 60 day");
        growth.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        growth.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        growth.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        growth.setWrapText(true); 
        growth.setMaxWidth(200); 
        
        
        
        Label season= new Label("Growing season:\nlate spring to midsummer");
        season.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        season.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        season.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        season.setWrapText(true); 
        season.setMaxWidth(200); 

        Button returnButton = new Button("Back");
        returnButton.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        returnButton .setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        returnButton.setStyle("-fx-font-size: 20px;"); 
        returnButton.setWrapText(true); 
        returnButton.setMaxWidth(200); 
       
        

        rightPane.getChildren().addAll(name, description, growth, season, returnButton);

        
        root.setLeft(leftPane);
        root.setRight(rightPane);

       
        returnButton.setOnAction(e -> {
 
            primaryStage.setScene(flowerListScene(primaryStage));
            
        });

        Flax = new Scene(root, 600, 600);
        
        return Flax;
    }
    
    public Scene DaisyScene(Stage primaryStage){
        
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(10));
        
        
        root.setStyle("-fx-background-color:#AAD7D9;");

        
        VBox leftPane = new VBox(10);
        leftPane.setPadding(new Insets(10));

       
        Rectangle square = new Rectangle(250, 250); 
        String filePath = "C:\\Users\\jack frost\\Downloads\\advanceProject\\flowers (2)\\flowers\\DAISY.jpeg";
        File file = new File(filePath);
        Image image = new Image(file.toURI().toString());
        square.setFill(new ImagePattern(image));
        square.setStroke(Color.web("#92C7CF"));
        square.setStrokeWidth(3); 

        
        Label price = new Label("Price:$5 ");
        price.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        price.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        price.setStyle("-fx-font-size: 20px; -fx-text-fill: black; -fx-background-color: white;");
        price.setWrapText(true); 
        price.setMaxWidth(200); 
        
       

        Button addToCartButton = new Button("Add to Cart");
        addToCartButton.setPrefWidth(160); 
        addToCartButton.setPrefHeight(40); 
        addToCartButton.setStyle("-fx-font-size: 20px;");
        addToCartButton.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        addToCartButton.setWrapText(true); 
        addToCartButton.setMaxWidth(200); 
        
        leftPane.getChildren().addAll(square, price, addToCartButton);
        
        addToCartButton.setOnAction(e -> addToCart(new Flower("Daisy", 5.0)));
        
        
        VBox rightPane = new VBox(10);
        rightPane.setPadding(new Insets(10));

        Label name = new Label("Calla");
        name.setPadding(new Insets(5, 5, 5, 75)); // Insets: top, right, bottom, left
        name.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        name.setStyle("-fx-font-size: 20px; -fx-text-fill: black; -fx-background-color: white;");
        name.setWrapText(true); 
        name.setMaxWidth(200);
        
        
        
        Label description = new Label("These sunny springtime blooms have several positive meanings. "
                + "The meaning of a daisy flower can be purity, innocence, new beginnings, joy and cheerfulness.");
        description.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        description.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        description.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        description.setWrapText(true); 
        description.setMaxWidth(200); 
        
        
        Label growth = new Label("Growth period:\n10-20 days");
        growth.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        growth.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        growth.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        growth.setWrapText(true); 
        growth.setMaxWidth(200); 
        
        
        
        Label season= new Label("Growing season:\nspring to fall");
        season.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        season.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        season.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        season.setWrapText(true); 
        season.setMaxWidth(200); 

        Button returnButton = new Button("Back");
        returnButton.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        returnButton .setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        returnButton.setStyle("-fx-font-size: 20px;"); 
        returnButton.setWrapText(true); 
        returnButton.setMaxWidth(200); 
        
        rightPane.getChildren().addAll(name, description, growth, season, returnButton);

        root.setLeft(leftPane);
        root.setRight(rightPane);

       
        returnButton.setOnAction(e -> {
 
            primaryStage.setScene(flowerListScene(primaryStage));
            
        });

        Daisy = new Scene(root, 600, 600);
        
        return Daisy;
    }
    
    public Scene daffodilScene(Stage primaryStage){
        
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(10));
        
        
        root.setStyle("-fx-background-color:#AAD7D9;");

        
        VBox leftPane = new VBox(10);
        leftPane.setPadding(new Insets(10));

       
        Rectangle square = new Rectangle(250, 250); 
        String filePath = "C:\\Users\\jack frost\\Downloads\\advanceProject\\flowers (2)\\flowers\\pink.jpeg";
        File file = new File(filePath);
        Image image = new Image(file.toURI().toString());
        square.setFill(new ImagePattern(image));
        square.setStroke(Color.web("#92C7CF"));
        square.setStrokeWidth(3); 

        
        Label price = new Label("Price:$5 ");
        price.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        price.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        price.setStyle("-fx-font-size: 20px; -fx-text-fill: black; -fx-background-color: white;");
        price.setWrapText(true); 
        price.setMaxWidth(200); 
        
       

        Button addToCartButton = new Button("Add to Cart");
        addToCartButton.setPrefWidth(160); 
        addToCartButton.setPrefHeight(40); 
        addToCartButton.setStyle("-fx-font-size: 20px;");
        addToCartButton.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        addToCartButton.setWrapText(true); 
        addToCartButton.setMaxWidth(200); 
        
        leftPane.getChildren().addAll(square, price, addToCartButton);
        
        addToCartButton.setOnAction(e -> addToCart(new Flower("daffodil", 5.0)));
        
        
        VBox rightPane = new VBox(10);
        rightPane.setPadding(new Insets(10));

        Label name = new Label("Daffodil");
        name.setPadding(new Insets(5, 5, 5, 75)); // Insets: top, right, bottom, left
        name.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        name.setStyle("-fx-font-size: 20px; -fx-text-fill: black; -fx-background-color: white;");
        name.setWrapText(true); 
        name.setMaxWidth(200);
        
        
        
        Label description = new Label("The daffodil symbolises rebirth and new beginnings.");
        description.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        description.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        description.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        description.setWrapText(true); 
        description.setMaxWidth(200); 
        
        
        
        
        Label growth = new Label("Growth period:\n12 to 15 weeks");
        growth.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        growth.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        growth.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        growth.setWrapText(true); 
        growth.setMaxWidth(200); 
        
        
        
        Label season= new Label("Growing season:\nspring");
        season.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        season.setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        season.setStyle("-fx-font-size: 15px; -fx-text-fill: black; -fx-background-color: white;");
        season.setWrapText(true); 
        season.setMaxWidth(200); 

        Button returnButton = new Button("Back");
        returnButton.setPadding(new Insets(5, 5, 5, 5)); // Insets: top, right, bottom, left
        returnButton .setBorder(new Border(new BorderStroke(Color.web("#92C7CF"),
        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,BorderWidths.DEFAULT))); 
        returnButton.setStyle("-fx-font-size: 20px;"); 
        returnButton.setWrapText(true); 
        returnButton.setMaxWidth(200); 
       
        

        rightPane.getChildren().addAll(name, description, growth, season, returnButton);

        
        root.setLeft(leftPane);
        root.setRight(rightPane);

       
        returnButton.setOnAction(e -> {
 
            primaryStage.setScene(flowerListScene(primaryStage));
            
        });

        daffodil = new Scene(root, 600, 600);
        
        return daffodil;
    }
    
    public Scene confScene(Stage primaryStage){
        
        totalPrice = 0.0;
        totalShip = 0.0;
        totalTax = 0.0;
        total0 = 0.0;

        GridPane root = new GridPane();
        VBox list = new VBox();
        list.setStyle("-fx-background-color: #DAFFFB");
        list.setPadding(new Insets(5, 5, 5, 5));
        root.setStyle("-fx-background-color: #DAFFFB");
        
        Rectangle title = new Rectangle(250, 50, Color.web("#64CCC5"));
        title.setStroke(Color.BLACK);
        Text tTitle = new Text("Thank You!");
        tTitle.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
        StackPane sTitle = new StackPane(title, tTitle);
        
        Rectangle title2 = new Rectangle(250, 50, Color.web("#64CCC5"));
        title2.setStroke(Color.BLACK);
        Text tTitle2 = new Text("Shopping List");
        tTitle2.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
        StackPane sTitle2 = new StackPane(title2, tTitle2);
        
        VBox cartItemList = new VBox();
        cartItemList.setSpacing(10);
        
         List<ShoppingCart> cartItems = getShoppingCartItems();

    for (ShoppingCart cartItem : cartItems) {
        Rectangle flowerRectangle = new Rectangle(50, 50, Color.web("#04364A"));
        flowerRectangle.setStroke(Color.BLACK);

        Rectangle flowerDetailsRectangle = new Rectangle(450, 50, Color.WHITE);
        flowerDetailsRectangle.setStroke(Color.BLACK);

        Label flowerLabel = new Label(cartItem.getFlowerName() + ": $" + cartItem.getPrice()+"   "+cartItem.getQuantity());
        flowerLabel.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));
        StackPane display = new StackPane(flowerDetailsRectangle, flowerLabel);
        
        totalPrice += cartItem.getPrice() * cartItem.getQuantity();
        totalShip += 5 * cartItem.getQuantity();
        totalTax += 0.25 * cartItem.getQuantity();
        total0 = totalPrice + totalShip + totalTax;

        HBox flowerBox = new HBox(5, flowerRectangle, display);
        flowerBox.setPadding(new Insets(25, 25, 25, 25));
        flowerBox.setAlignment(Pos.CENTER_LEFT);
        
        ScrollBar sbVertical = new ScrollBar();
        sbVertical.setOrientation(Orientation.VERTICAL);
         
         sbVertical.valueProperty().addListener(ov->
                root.setTranslateY(sbVertical.getValue()*root.getHeight()/
                        sbVertical.getMax()));

        cartItemList.getChildren().add(flowerBox);
    }
    
         
    ScrollPane scrollPane = new ScrollPane();
    scrollPane.setContent(cartItemList);
    scrollPane.setFitToWidth(true);
    scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);

    Text totalText = new Text("Total:- $" + total0);
    
    HBox buttonBox = new HBox(10);
    Button backButton = new Button("Back");
    backButton.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));
    backButton.setStyle("-fx-background-color: #64CCC5");
    
    Button bFile = new Button("Export to file");
    bFile.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));
    bFile.setStyle("-fx-background-color: #64CCC5");
    
    buttonBox.setAlignment(Pos.CENTER);
    buttonBox.getChildren().addAll(totalText ,backButton,bFile);

    list.getChildren().addAll(sTitle, scrollPane);
    root.add(sTitle, 0, 0, 2, 1);
    root.add(scrollPane, 0, 3, 2, 1);
    root.add(buttonBox, 0, 4, 4, 1);
    
    
    bFile.setOnAction(e->{
       writeDataToFile(cartItems); 
    });
        
        backButton.setOnAction(e ->{
        cartItems.clear();
        cartItemList.getChildren().clear();
        totalText.setText("Total:- $" + total0);
        primaryStage.setScene(flowerListScene(primaryStage));
        
    });
        
        confScene = new Scene(root,600,600);
        return confScene;
    }
    
   private void writeDataToFile(List<ShoppingCart> cartItems) {
    try {
        File file = new File("order_details.txt");
        FileWriter fileWriter = new FileWriter(file);

        for (int i = 0; i < cartItems.size(); i++) {
            ShoppingCart cartItem = cartItems.get(i);
            fileWriter.write((i + 1) + "- Flower Name: " + cartItem.getFlowerName() +
                    ", Price: $" + cartItem.getPrice() +
                    ", Quantity: " + cartItem.getQuantity() +
                    System.lineSeparator());
        }
            fileWriter.write("\nTotal Price: $"+totalPrice);
            fileWriter.write("\nTotal Shipment: $"+totalShip);
            fileWriter.write("\nToatal Tax: $"+totalTax);
            fileWriter.write("\nTotal: $ "+total0);
        
        fileWriter.close();
        System.out.println("Order details written to file successfully.");

    } catch (IOException e) {
        e.printStackTrace();
    }
}
    
    public Scene cartScene(Stage primaryStage){
    GridPane root = new GridPane();
    VBox list = new VBox();
    list.setStyle("-fx-background-color: #DAFFFB");
    list.setPadding(new Insets(5, 5, 5, 5));
    root.setStyle("-fx-background-color: #DAFFFB");
    
    totalPrice = 0.0;
    totalShip = 0.0;
    totalTax = 0.0;
    total0 = 0.0;

    Rectangle title = new Rectangle(250, 50, Color.web("#64CCC5"));
    title.setStroke(Color.BLACK);
    Text tTitle = new Text("Shopping Cart");
    tTitle.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
    StackPane sTitle = new StackPane(title, tTitle);

    
    cartItemList.setSpacing(10);
    
        Line line = new Line();
        line.setStartX(50);
        line.setEndX(100);
        line.setStartY(0);
        line.setEndY(0);
    
        VBox priceVBox = new VBox(priceText, shipmentText, taxText, line, totalText);
        priceVBox.setAlignment(Pos.CENTER);
        Rectangle priceRectangle = new Rectangle(300, 100, Color.WHITE);
        priceRectangle.setStroke(Color.BLACK);
        StackPane pricePane = new StackPane(priceRectangle, priceVBox);

        // Assuming you have a method getShoppingCartItems() to retrieve cart items
        List<ShoppingCart> cartItems = getShoppingCartItems();

    for (ShoppingCart cartItem : cartItems) {
        
        Rectangle flowerRectangle = new Rectangle(50, 50, Color.web("#04364A"));
        flowerRectangle.setStroke(Color.BLACK);

        Rectangle flowerDetailsRectangle = new Rectangle(450, 50, Color.WHITE);
        flowerDetailsRectangle.setStroke(Color.BLACK);
        
        Button increaseButton = new Button("+");
        Button decreaseButton = new Button("-");

        // Set styles for the buttons
        increaseButton.setStyle("-fx-background-color: #64CCC5");
        decreaseButton.setStyle("-fx-background-color: #64CCC5");

        flowerLabel = new Label(cartItem.getFlowerName() + ": $" + cartItem.getPrice()+"   "+cartItem.getQuantity());
        flowerLabel.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));
        HBox quantityControlBox = new HBox(5, decreaseButton, increaseButton);
        quantityControlBox.setAlignment(Pos.CENTER_RIGHT);
        quantityControlBox.setPadding(new Insets(0, 10, 0, 0));

        HBox flowerLabelBox = new HBox(flowerLabel, quantityControlBox);
        flowerLabelBox.setAlignment(Pos.CENTER_LEFT);

        // Update the display
        StackPane display = new StackPane(flowerDetailsRectangle, flowerLabelBox);

        HBox flowerBox = new HBox(5, flowerRectangle, display);
        flowerBox.setPadding(new Insets(25, 25, 25, 25));
        flowerBox.setAlignment(Pos.CENTER_LEFT);
        
        
         flowerRectangle.setOnMouseClicked(e -> {
            if (e.getButton() == MouseButton.PRIMARY) {
                // Remove the corresponding item from the shopping cart
                shoppingCart.remove(cartItem);
                
                totalPrice -= cartItem.getPrice() * cartItem.getQuantity();
                totalShip -= 5 * cartItem.getQuantity();
                totalTax -= 0.25 * cartItem.getQuantity();
                total0 = totalPrice + totalShip + totalTax;
                
                shipmentText.setText("Shipment:- $" + totalShip);
                priceText.setText("Price:- $" + totalPrice);
                taxText.setText("Tax:- $" + totalTax);
                totalText.setText("Total:- $" + total0);

                // Update the display
                cartItemList.getChildren().remove(flowerBox);
            }
            e.consume();
        });
         
    increaseButton.setOnAction(event -> {
        cartItem.setQuantity(cartItem.getQuantity() + 1);
        updateCartDisplay();
    });

    decreaseButton.setOnAction(event -> {
        if (cartItem.getQuantity() > 1) {
            cartItem.setQuantity(cartItem.getQuantity() - 1);
            updateCartDisplay();
        }
    });

         
        ScrollBar sbVertical = new ScrollBar();
        sbVertical.setOrientation(Orientation.VERTICAL);
        
        
         
         sbVertical.valueProperty().addListener(ov->
                root.setTranslateY(sbVertical.getValue()*root.getHeight()/
                        sbVertical.getMax()));

        cartItemList.getChildren().add(flowerBox);
        
        totalPrice += cartItem.getPrice() * cartItem.getQuantity();
        totalShip += 5 * cartItem.getQuantity();
        totalTax += 0.25 * cartItem.getQuantity();
        total0 = totalPrice + totalShip + totalTax;

        // Update price labels
        shipmentText.setText("Shipment:- $" + totalShip);
        priceText.setText("Price:- $" + totalPrice);
        taxText.setText("Tax:- $" + totalTax);
        totalText.setText("Total:- $" + total0);
    }
    
    ScrollPane scrollPane = new ScrollPane();
    scrollPane.setContent(cartItemList);
    scrollPane.setFitToWidth(true);
    scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);
    
    HBox buttonBox = new HBox(10);
    Button confirmButton = new Button("Confirm");
    confirmButton.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));
    confirmButton.setStyle("-fx-background-color: #64CCC5");
    Button backButton = new Button("Back");
    backButton.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));
    backButton.setStyle("-fx-background-color: #64CCC5");
    buttonBox.getChildren().addAll(confirmButton, backButton);
    
    StackPane paymentBox = createPaymentBox(primaryStage);
    Label errorLabel = new Label("");
    errorLabel.setTextFill(Color.RED);
    
    list.getChildren().addAll(sTitle, scrollPane, paymentBox,pricePane);
    root.add(sTitle, 0, 0, 2, 1);
    root.add(scrollPane, 0, 1, 2, 1);
    root.add(paymentBox, 0, 2, 1, 1);
    root.add(pricePane, 1, 2, 1, 1);
    root.add(buttonBox, 1, 3, 1, 1);
    root.add(errorLabel, 0, 4, 2, 1);  
    
    backButton.setOnAction(e ->{
        primaryStage.setScene(flowerListScene(primaryStage));
    });

    confirmButton.setOnAction(e -> {
    if (rbCredit.isSelected()) {
        primaryStage.setScene(payScene(primaryStage));
         if (cartItemList.getChildren().isEmpty()) {
            // Display an error message if the cart is empty
            errorLabel.setText("Error: Your cart is empty. Add items before confirming.");
        } 
    } else if (rbCash.isSelected()) {
        if (cartItemList.getChildren().isEmpty()) {
            // Display an error message if the cart is empty
            errorLabel.setText("Error: Your cart is empty. Add items before confirming.");
        } else {
            // Clear the error message and proceed with the confirmation
            errorLabel.setText("");
            cartItemList.getChildren().clear();
            totalShip = 0.0;
            totalPrice = 0.0;
            totalTax = 0.0;
            total0 = 0.0;
            shipmentText.setText("Shipment:- $" + totalShip);
            priceText.setText("Price:- $" + totalPrice);
            taxText.setText("Tax:- $" + totalTax);
            totalText.setText("Total:- $" + total0);
            primaryStage.setScene(confScene(primaryStage));
        }
    } else {
        // Display an error message if no payment method is selected
        errorLabel.setText("Error: Please choose a payment method.");
    }
});
    
    
    cartScene = new Scene(root, 600, 600);
    return cartScene;
}
   
    
    private void updateCartDisplay(){

    // Update the quantities and total values
    totalPrice = 0.0;
    totalShip = 0.0;
    totalTax = 0.0;
    total0 = 0.0;

    for (ShoppingCart cartItem : cartItems) {
        
        totalPrice += cartItem.getPrice() * cartItem.getQuantity();
        totalShip += 5 * cartItem.getQuantity();
        totalTax += 0.25 * cartItem.getQuantity();
        total0 = totalPrice + totalShip + totalTax;
        
        flowerLabel.setText(cartItem.getFlowerName() + ": $" + cartItem.getPrice()+"   "+cartItem.getQuantity());
        
        // Update price labels
        shipmentText.setText("Shipment:- $" + totalShip);
        priceText.setText("Price:- $" + totalPrice);
        taxText.setText("Tax:- $" + totalTax);
        totalText.setText("Total:- $" + total0);
    }
}
    
    
    private StackPane createPaymentBox(Stage primaryStage) {
    
    VBox paymentBox = new VBox();
    paymentBox.setSpacing(10);
    paymentBox.setPadding(new Insets(25, 25, 25, 25));
    paymentBox.setStyle("-fx-background-color: #DAFFFB");

    Text payM = new Text("Payment Method: ");
    payM.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));

    rbCash = new RadioButton("Cash");
    rbCash.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));

    rbCredit = new RadioButton("Credit card");
    rbCredit.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));

    ToggleGroup group = new ToggleGroup();
    rbCash.setToggleGroup(group);
    rbCredit.setToggleGroup(group);
    
    
    Rectangle r = new Rectangle(200, 70, Color.WHITE);
    r.setStroke(Color.BLACK);
    
    paymentBox.getChildren().addAll(payM, rbCash, rbCredit);

    StackPane pane = new StackPane(r,paymentBox);

    return pane;
}
    
    public Scene payScene(Stage primaryStage){
        
     VBox root = new VBox(50); 
    root.setStyle("-fx-background-color: #DAFFFB");
    root.setAlignment(Pos.CENTER);

    // Title
    Rectangle title = new Rectangle(250, 50, Color.web("#64CCC5"));
    title.setStroke(Color.BLACK);
    Text tTitle = new Text("Payment Details");
    tTitle.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
    StackPane sTitle = new StackPane(title, tTitle);
    root.getChildren().add(sTitle);

    // Display total payments
    Label totalPaymentsLabel = new Label("Total:- $" + total0);
    root.getChildren().add(totalPaymentsLabel);

    // Text fields for entering card details
    TextField cardNumberTextField = new TextField("Enter Card Number");
    TextField expirationDateTextField = new TextField("Enter Expiration Date (MM/YY)");
    TextField amountTextField = new TextField("Enter Amount to Pay");
    
    cardNumberTextField.setPrefWidth(100);
    expirationDateTextField.setPrefWidth(100);
    amountTextField.setPrefWidth(50);

    root.getChildren().addAll(cardNumberTextField, expirationDateTextField, amountTextField);

    // Button for processing the payment
    Button payButton = new Button("Pay");
    payButton.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));
    payButton.setStyle("-fx-background-color: #64CCC5");
    root.getChildren().add(payButton);

    // Button action
   payButton.setOnAction(e -> {
            removeWarningLabels(root);
            // Check if any of the text fields is empty
            if (cardNumberTextField.getText().isEmpty() ||
                    expirationDateTextField.getText().isEmpty() ||
                    amountTextField.getText().isEmpty()) {
                Label warningLabel = new Label("Warning: All fields must be filled!");
                warningLabel.setStyle("-fx-text-fill: red;");
                root.getChildren().add(warningLabel);
            } else if (!isValidCardNumber(cardNumberTextField.getText())) {
                Label invalidCardLabel = new Label("Warning: Invalid Card Number!");
                invalidCardLabel.setStyle("-fx-text-fill: red;");
                root.getChildren().add(invalidCardLabel);
            } else if (!isValidExpirationDate(expirationDateTextField.getText())) {
                Label invalidDateLabel = new Label("Warning: Invalid Expiration Date (MM/YY)!");
                invalidDateLabel.setStyle("-fx-text-fill: red;");
                root.getChildren().add(invalidDateLabel);
            } else if (total0 != Double.parseDouble(amountTextField.getText())) {
                Label discrepancyLabel = new Label("Warning: Total Payments do not match Entered Price!");
                discrepancyLabel.setStyle("-fx-text-fill: red;");
                root.getChildren().add(discrepancyLabel);
            } else {
                // Payment processing logic
                cartItemList.getChildren().clear();
                totalPrice = 0.0;
                totalShip = 0.0;
                totalTax = 0.0;
                total0 = 0.0;
                shipmentText.setText("Shipment:- $" + totalShip);
                priceText.setText("Price:- $" + totalPrice);
                taxText.setText("Tax:- $" + totalTax);
                totalText.setText("Total:- $" + total0);
                primaryStage.setScene(confScene(primaryStage));
            }
        });
    
    payScene = new Scene(root, 600, 600);
        
    return payScene;
}
    
    private boolean isValidCardNumber(String cardNumber) {
        // Use a regular expression to check for a valid card number format
        // For simplicity, this example checks for 16 digits
        return Pattern.matches("\\d{16}", cardNumber);
    }
    
    private boolean isValidExpirationDate(String expirationDate) {
        // Use a regular expression to check for a valid expiration date format (MM/YY)
        return Pattern.matches("(0[1-9]|1[0-2])/(\\d{2})", expirationDate);
    }
    
    private void removeWarningLabels(VBox root) {
    root.getChildren().removeIf(node -> node instanceof Label && ((Label) node).getText().startsWith("Warning:"));
}
    
    public Scene flowerListScene(Stage primaryStage){
        
       // root node
        BorderPane pane = new BorderPane(); 
        
        // hbox for searchbar and button in the top pane
        HBox paneSearch = new HBox();
        paneSearch.setStyle("-fx-background-color: #AAD7D9; -fx-border-color: #92C7CF ;-fx-border-width: 3px");
        paneSearch.setSpacing(10);
        paneSearch.setPadding(new Insets(15,15,15,15));
        paneSearch.setAlignment(Pos.CENTER_LEFT);
        
        // the shop name in the top pane
        Text title = new Text("Flowerz");
        title.setFill(Color.rgb(73,90,91));
        title.setFont(Font.font("Times new roman", FontWeight.BOLD,FontPosture.ITALIC, 25));
        
        // search bar
        TextField searchTF = new TextField();
        searchTF.setPromptText("Search");// promt text inside it
        searchTF.setPrefWidth(320);
        searchTF.setPadding(new Insets(5,5,5,5));
        
        //search button 
        Button srchButton = new Button("Search");
        srchButton.setStyle("-fx-background-color: #FBF9F1;");
        
        //create register
//        srchButton.setOnAction(eh);
        
        // adding them to the hbox 
        paneSearch.getChildren().addAll(title,searchTF, srchButton);
        
        // Flower images
        Image poppy = new Image("file:C:\\Users\\jack frost\\Downloads\\advanceProject\\flowers (2)\\flowers\\poppy.jpeg");
        ImageView imageView1 = new ImageView(poppy);
        imageView1.setFitWidth(110);
        imageView1.setFitHeight(100);
        imageView1.setTranslateY(-50);
   
        Image calla = new Image("file:C:\\Users\\jack frost\\Downloads\\advanceProject\\flowers (2)\\flowers\\calla.jpeg");
        ImageView imageView2 = new ImageView(calla);
        imageView2.setFitWidth(109);
        imageView2.setFitHeight(100); 
        imageView2.setTranslateY(-50);
//        imageView2.setPreserveRatio(true);
        
        Image orchid = new Image("file:C:\\Users\\jack frost\\Downloads\\advanceProject\\flowers (2)\\flowers\\orchid.jpeg");
        ImageView imageView3 = new ImageView(orchid);
        imageView3.setFitWidth(115);
        imageView3.setFitHeight(100); 
        imageView3.setTranslateY(-50);
        
        Image lily = new Image("file:C:\\Users\\jack frost\\Downloads\\advanceProject\\flowers (2)\\flowers\\lily.jpeg");
        ImageView imageView4 = new ImageView(lily);
        imageView4.setFitWidth(110);
        imageView4.setFitHeight(100); 
        imageView4.setTranslateY(-50);
        
        
        Image iris = new Image("file:C:\\Users\\jack frost\\Downloads\\advanceProject\\flowers (2)\\flowers\\IRISjpeg.jpeg");
        ImageView imageView5 = new ImageView(iris);
        imageView5.setFitWidth(99);
        imageView5.setFitHeight(100); 
        imageView5.setTranslateY(-50);
       
        Image flax = new Image("file:C:\\Users\\jack frost\\Downloads\\advanceProject\\flowers (2)\\flowers\\flax.jpeg");
        ImageView imageView6 = new ImageView(flax);
        imageView6.setFitWidth(110);
        imageView6.setFitHeight(100); 
        imageView6.setTranslateY(-50);
        
        Image daisy = new Image("file:C:\\Users\\jack frost\\Downloads\\advanceProject\\flowers (2)\\flowers\\DAISY.jpeg");
        ImageView imageView7 = new ImageView(daisy);
        imageView7.setFitWidth(110);
        imageView7.setFitHeight(100); 
        imageView7.setTranslateY(-50);
        
        Image daffodil = new Image("file:C:\\Users\\jack frost\\Downloads\\advanceProject\\flowers (2)\\flowers\\pink.jpeg");
        ImageView imageView8 = new ImageView(daffodil);
        imageView8.setFitWidth(110);
        imageView8.setFitHeight(100); 
        imageView8.setTranslateY(-50);
        
        // list buttons
        Button flowerBtn = new Button("Add");
        flowerBtn.setStyle("-fx-background-color: #FBF9F1;");
        
        Button flowerBtn1 = new Button("Add");
        flowerBtn1.setStyle("-fx-background-color: #FBF9F1;");
        
        Button flowerBtn2 = new Button("Add");
        flowerBtn2.setStyle("-fx-background-color: #FBF9F1;");
        
        Button flowerBtn3 = new Button("Add");
        flowerBtn3.setStyle("-fx-background-color: #FBF9F1;");
        
        Button flowerBtn4 = new Button("Add");
        flowerBtn4.setStyle("-fx-background-color: #FBF9F1;");
        
        Button flowerBtn5 = new Button("Add");
        flowerBtn5.setStyle("-fx-background-color: #FBF9F1;");
        
        Button flowerBtn6 = new Button("Add");
        flowerBtn6.setStyle("-fx-background-color: #FBF9F1;");
        
        Button flowerBtn7 = new Button("Add");
        flowerBtn7.setStyle("-fx-background-color: #FBF9F1;");
		
	flowerBtn.setOnAction(e -> addToCart(new Flower("Poppy", 5.0)));
        flowerBtn1.setOnAction(e -> addToCart(new Flower("Calla", 5.0)));
        flowerBtn2.setOnAction(e -> addToCart(new Flower("Orchid", 5.0)));
        flowerBtn3.setOnAction(e -> addToCart(new Flower("Lily", 5.0)));
        flowerBtn4.setOnAction(e -> addToCart(new Flower("Iris", 5.0)));
        flowerBtn5.setOnAction(e -> addToCart(new Flower("Flax", 5.0)));
        flowerBtn6.setOnAction(e -> addToCart(new Flower("Daisy", 5.0)));
        flowerBtn7.setOnAction(e -> addToCart(new Flower("daffodil", 5.0)));
        
        
        // cart button
        Button cartBtn = new Button("  Cart  ");
        cartBtn.setStyle("-fx-background-color: #FBF9F1;");

        // hbox to add cart button in
        HBox cartBox = new HBox();
        cartBox.setAlignment(Pos.CENTER_RIGHT);
        cartBox.setSpacing(10);
        cartBox.setPadding(new Insets(15,15,15,15));
        cartBox.setStyle("-fx-background-color: #AAD7D9; -fx-border-color: #92C7CF ;-fx-border-width: 3px");
        cartBox.getChildren().add(cartBtn);
        
        
        //labels for flowers menu (names and prices)
        Label lb1 = new Label("Poppy    5 S.R.",flowerBtn);
        lb1.setStyle("-fx-background-color: #FBF9F1;");
        lb1.setContentDisplay(ContentDisplay.RIGHT);
        
        Label lb2 = new Label("Calla    5 S.R.",flowerBtn1);
        lb2.setStyle("-fx-background-color: #FBF9F1;");
        lb2.setContentDisplay(ContentDisplay.RIGHT);
        lb2.setAlignment(Pos.CENTER);
        
        Label lb3 = new Label("Orchid    5 S.R.",flowerBtn2);
        lb3.setStyle("-fx-background-color: #FBF9F1;");
        lb3.setContentDisplay(ContentDisplay.RIGHT);
        lb3.setAlignment(Pos.CENTER);
        
        Label lb4 = new Label(" Lily    5 S.R. ",flowerBtn3);
        lb4.setStyle("-fx-background-color: #FBF9F1;");
        lb4.setContentDisplay(ContentDisplay.RIGHT);
        lb4.setAlignment(Pos.CENTER);
        
        Label lb5 = new Label("Iris    5 S.R.",flowerBtn4);
        lb5.setStyle("-fx-background-color: #FBF9F1;");
        lb5.setContentDisplay(ContentDisplay.RIGHT);
        lb5.setAlignment(Pos.CENTER);
        
        Label lb6 = new Label(" Flax    5 S.R. ",flowerBtn5);
        lb6.setStyle("-fx-background-color: #FBF9F1;");
        lb6.setContentDisplay(ContentDisplay.RIGHT);
        lb6.setAlignment(Pos.CENTER);
        
        Label lb7 = new Label("Daisy    5 S.R.",flowerBtn6);
        lb7.setStyle("-fx-background-color: #FBF9F1;");
        lb7.setContentDisplay(ContentDisplay.RIGHT);
        lb7.setAlignment(Pos.CENTER);
        
        Label lb8 = new Label("Daffodil    5 S.R.",flowerBtn7);
        lb8.setStyle("-fx-background-color: #FBF9F1;");
        lb8.setContentDisplay(ContentDisplay.RIGHT);
        lb8.setAlignment(Pos.CENTER);
        
        
        //stackpane to combine flower pictures with their labels
        StackPane stkPane1 = new StackPane();
        stkPane1.getChildren().addAll(imageView1,lb1);
        stkPane1.setPrefHeight(120);
        stkPane1.setPrefWidth(120);
       
        StackPane stkPane2 = new StackPane();
        stkPane2.getChildren().addAll(imageView2,lb2);
        stkPane2.setPrefHeight(120);
        stkPane2.setPrefWidth(120);
        
        StackPane stkPane3 = new StackPane();
        stkPane3.getChildren().addAll(imageView3,lb3);
        stkPane3.setPrefHeight(120);
        stkPane3.setPrefWidth(120);
        
        StackPane stkPane4 = new StackPane();
        stkPane4.getChildren().addAll(imageView4,lb4);
        stkPane4.setPrefHeight(120);
        stkPane4.setPrefWidth(120);
        
        StackPane stkPane5 = new StackPane();
        stkPane5.getChildren().addAll(imageView5,lb5);
        stkPane5.setPrefHeight(120);
        stkPane5.setPrefWidth(120);
        
        StackPane stkPane6 = new StackPane();
        stkPane6.getChildren().addAll(imageView6,lb6);
        stkPane6.setPrefHeight(120);
        stkPane6.setPrefWidth(120);
        
        StackPane stkPane7 = new StackPane();
        stkPane7.getChildren().addAll(imageView7,lb7);
        stkPane7.setPrefHeight(120);
        stkPane7.setPrefWidth(120);
        
        StackPane stkPane8 = new StackPane();
        stkPane8.getChildren().addAll(imageView8,lb8);
        stkPane8.setPrefHeight(120);
        stkPane8.setPrefWidth(120);
        
        
        //firts list of flowers
        HBox list1 = new HBox(15);
        list1.getChildren().addAll(stkPane1,stkPane2,stkPane3,stkPane4);

        // second list of flowers
        HBox list2 = new HBox(15);
        list2.getChildren().addAll(stkPane5,stkPane6,stkPane7,stkPane8);

        
        // to adjust the lists on top of each other
        GridPane gridpane = new GridPane();
        
        gridpane.setPadding(new Insets(5,5,5,5));
        gridpane.setVgap(80);
        gridpane.setHgap(80);
        gridpane.setAlignment(Pos.CENTER);
        
        gridpane.add(list1, 0, 1);
        gridpane.add(list2, 0, 2);
        
        
        //scroll bar for this page
        ScrollBar sbVertical = new ScrollBar();
        sbVertical.setOrientation(Orientation.VERTICAL);
        // listener for vertical scrollbar value change
        sbVertical.valueProperty().addListener(ov->
                gridpane.setTranslateY(sbVertical.getValue()*gridpane.getHeight()/
                        sbVertical.getMax()));
        
        pane.setTop(paneSearch);
        pane.setRight(sbVertical);
        pane.setCenter(gridpane);
        pane.setBottom(cartBox);
        
        flowerListScene = new Scene(pane,600,600);
        flowerListScene.setFill(Color.rgb(201,199,187));
        
        
        ObservableList<String> flowerList = FXCollections.observableArrayList("Poppy","Lily","Calla","Orchid","Iris","Flax","Daisy","Rose");

        // lambda action event
        srchButton.setOnAction((ActionEvent e)->{
String searchText = searchTF.getText().toLowerCase();
    boolean isFound = false;

    // Iterate through the flowerList
    for (int i = 0; i < flowerList.size(); i++) {
        String flower = flowerList.get(i).toLowerCase();
        if (flower.equals(searchText)) {
            System.out.println(flower + " is found");
            // Highlight the matching flower in the UI
          if (flower.matches("poppy")) {
                lb1.setStyle("-fx-background-color: #FFEB99;"); // Change background color to highlight
                flowerBtn.setStyle("-fx-background-color: #FFEB99;"); // Change background color to highlight
            }
          if (flower.matches("calla")) {
              lb2.setStyle("-fx-background-color: #FFEB99;"); // Change background color to highlight
              flowerBtn1.setStyle("-fx-background-color: #FFEB99;"); // Change background color to highlight
          }
          if (flower.matches("orchid")) {
              lb3.setStyle("-fx-background-color: #FFEB99;"); // Change background color to highlight
              flowerBtn2.setStyle("-fx-background-color: #FFEB99;"); // Change background color to highlight
          }
          if (flower.matches("lily")) {
              lb4.setStyle("-fx-background-color: #FFEB99;"); // Change background color to highlight
              flowerBtn3.setStyle("-fx-background-color: #FFEB99;"); // Change background color to highlight
          }   
          if (flower.matches("iris")) {
              lb5.setStyle("-fx-background-color: #FFEB99;"); // Change background color to highlight
              flowerBtn4.setStyle("-fx-background-color: #FFEB99;"); // Change background color to highlight
          }
          if (flower.matches("flax")) {
              lb6.setStyle("-fx-background-color: #FFEB99;"); // Change background color to highlight
              flowerBtn5.setStyle("-fx-background-color: #FFEB99;"); // Change background color to highlight
          }
          if (flower.matches("daisy")) {
              lb7.setStyle("-fx-background-color: #FFEB99;"); // Change background color to highlight
              flowerBtn6.setStyle("-fx-background-color: #FFEB99;"); // Change background color to highlight
          }
          if (flower.matches("rose")) {
              lb8.setStyle("-fx-background-color: #FFEB99;"); // Change background color to highlight
              flowerBtn7.setStyle("-fx-background-color: #FFEB99;"); // Change background color to highlight
          }
          
            isFound = true;
            break; // Exit the loop if a match is found
        }
    }

    if (!isFound) {
        // Create a temporary container for the message
        StackPane msgContainer = new StackPane();
        msgContainer.setAlignment(Pos.CENTER);
        pane.setCenter(msgContainer); // Add it to the center of the main pane

        // Create the message text
        Text msg = new Text("Flower not found");
        msg.setTextAlignment(TextAlignment.CENTER);
        msg.setFont(Font.font("Verdana", FontWeight.MEDIUM, 15));
        msgContainer.getChildren().add(msg);

        // Create a pause transition to make the message disappear
        PauseTransition delay = new PauseTransition(Duration.seconds(5)); // Adjust delay as needed
        delay.setOnFinished((ActionEvent e2) -> {
            pane.setCenter(gridpane); // Restore the original layout
        });
        delay.play();
        
    }
       
        
        // Display a message in the UI saying the item is not found
        // (You'll need to add a suitable UI element to display this message)
    });
	
	 lb1.setOnMouseClicked(e->{
            if (e.getButton() == MouseButton.PRIMARY) { 
                primaryStage.setScene(poppyScene(primaryStage));
            }
        });
        lb2.setOnMouseClicked(e->{
            if (e.getButton() == MouseButton.PRIMARY) { 
                primaryStage.setScene(callaScene(primaryStage));
            }
        });
        lb3.setOnMouseClicked(e->{
            if (e.getButton() == MouseButton.PRIMARY) { 
                primaryStage.setScene(OrchidScene(primaryStage));
            }
        });
        lb4.setOnMouseClicked(e->{
            if (e.getButton() == MouseButton.PRIMARY) { 
                primaryStage.setScene(LilyScene(primaryStage));
            }
        });
        lb5.setOnMouseClicked(e->{
            if (e.getButton() == MouseButton.PRIMARY) { 
                primaryStage.setScene(IrisScene(primaryStage));
            }
        });
        lb6.setOnMouseClicked(e->{
            if (e.getButton() == MouseButton.PRIMARY) { 
                primaryStage.setScene(FlaxScene(primaryStage));
            }
        });
        lb7.setOnMouseClicked(e->{
            if (e.getButton() == MouseButton.PRIMARY) { 
                primaryStage.setScene(DaisyScene(primaryStage));
            }
        });
        lb8.setOnMouseClicked(e->{
            if (e.getButton() == MouseButton.PRIMARY) { 
                primaryStage.setScene(daffodilScene(primaryStage));
            }
        });
        
        cartBtn.setOnAction(e->{
            primaryStage.setScene(cartScene(primaryStage));
        });
        
        return flowerListScene;
    }
    
    private void addToCart(Flower flower) {

      for (ShoppingCart cartItem : shoppingCart) {
        if (cartItem.getFlowerName().equals(flower.getFlowName())) {
            // If yes, increase the quantity
            cartItem.setQuantity(cartItem.getQuantity() + 1);
            updateCartDisplay(); // Update the display after modifying the quantity
            return;
        }
    }

      Random randomNum = new Random();
      int randomNumber = randomNum.nextInt(100);
      
    // If not, add a new item to the cart
        ShoppingCart cart = new ShoppingCart(flower.getFlowName(), flower.getPrice(), 1);
        cart.setCart_id(randomNumber);
        shoppingCart.add(cart);
        
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        int sId2 = (Integer) session.save(cart);
        tx.commit();
        session.close();
        
        updateCartDisplay(); // Update the display after adding a new item
    }
    
    public List<ShoppingCart> getShoppingCartItems() {
        return shoppingCart;
    }
    
    public Scene signUpScene(Stage primaryStage){
        
        GridPane pane = new GridPane();  
        pane.setHgap(0);
        pane.setVgap(5);
        HBox p1 = new HBox(20);
        Circle c1 = new Circle();
        c1.setFill(Color.WHITE);
        c1.setCenterX(90); 
        c1.setCenterY(300);
        c1.setRadius(70);
        p1.setAlignment(Pos.TOP_CENTER);
        Image l=new Image("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT2cCq6zKhvaV2u5fP07uVphRJbs8fTLxIwTA&usqp=CAU");
        c1.setFill(new ImagePattern(l));//to put the pic in the circle
        c1.setStroke(Color.LIGHTBLUE);
        c1.setStrokeWidth(3);
        p1.getChildren().addAll(c1); p1.setAlignment(Pos.TOP_CENTER); BorderPane pane1 = new BorderPane(); pane1.setTop(p1);

        VBox p2 = new VBox(10);//username and password textfiled
       
        TextField UName; 
        TextField pass;
        TextField email;
        TextField phoneNumber;
        TextField FName;
        TextField LName;
        
        Label l1 = new Label("User name: "); l1.setMinWidth(150); l1.setAlignment(Pos.BOTTOM_LEFT);
        l1.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));
        UName = new TextField(); UName.setMinWidth(200); UName.setMaxWidth(200); 
        Label l2 = new Label("Password:"); l2.setMinWidth(100); l2.setAlignment(Pos.BOTTOM_LEFT);
        l2.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));
        pass = new TextField(); pass.setMinWidth(200); pass.setMaxWidth(200);
        Label l3 = new Label("First Name:"); l3.setMinWidth(100); l3.setAlignment(Pos.BOTTOM_LEFT);
        l3.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));
        FName = new TextField(); FName.setMinWidth(200); FName.setMaxWidth(200);
        Label l4 = new Label("Last Name:"); l4.setMinWidth(100); l4.setAlignment(Pos.BOTTOM_LEFT);
        l4.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));
        LName = new TextField(); LName.setMinWidth(200); LName.setMaxWidth(200);
        Label l5 = new Label("Email:"); l5.setMinWidth(100); l5.setAlignment(Pos.BOTTOM_LEFT);
        l5.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));
        email = new TextField(); email.setMinWidth(200); email.setMaxWidth(200);
        Label l6 = new Label("Phone Number:"); l6.setMinWidth(100); l6.setAlignment(Pos.BOTTOM_LEFT);
        l6.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));
        phoneNumber = new TextField(); phoneNumber.setMinWidth(200); phoneNumber.setMaxWidth(200);
        
        Button btBack = new Button("      Back      ");
        btBack.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));
        btBack.setStyle("-fx-background-color: #64CCC5");
        
        p2.getChildren().addAll(l1,UName,l2,pass,l3,FName,l4,LName,l5,email,l6,phoneNumber,btBack);
        p2.setAlignment(Pos.CENTER_LEFT); 
        BorderPane pane2 = new BorderPane(); 
        pane2.setTop(p2);

        Text t2 = new Text("\n \n  \n ");//to bring the pic a lil lower in the screen

        VBox p3 = new VBox(10);//log n button
        Button bt1 = new Button("           Sign-Up           ");
        bt1.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 10));
        bt1.setStyle("-fx-background-color: #64CCC5");
        bt1.setAlignment(Pos.BOTTOM_RIGHT);
        p3.getChildren().addAll(bt1); p3.setAlignment(Pos.CENTER); BorderPane pane3 = new BorderPane(); pane3.setTop(p3);

        pane.setStyle("-fx-background-color: #DAFFFB");
        
        //adding to the screen
        pane.add(t2,1,0);
        pane.add(p1,1,1);
        pane.add(p2,1,2);
        pane.add(p3,1,4);
        pane.setAlignment(Pos.TOP_CENTER); 

    signUpScene = new Scene(pane,600,630);
      Label errorMessageLabel = new Label();
errorMessageLabel.setTextFill(Color.RED);
pane.add(errorMessageLabel, 1, 3);


       bt1.setOnAction(e -> {
            String username = UName.getText();
            String password = pass.getText();
            String firstName = FName.getText();
            String lastName = LName.getText();
            String userEmail = email.getText();
            String userPhoneNumber = phoneNumber.getText();

            // Clear previous error messages
            errorMessageLabel.setText("");

            // Continue with other validations...
            if (username.isEmpty() || password.isEmpty() || firstName.isEmpty() || lastName.isEmpty() ||
                    userEmail.isEmpty() || userPhoneNumber.isEmpty()) {
                errorMessageLabel.setText("Please fill in all required fields.");
            } else if (!isValidEmail(userEmail)) {
                errorMessageLabel.setText("Please enter a valid email address. \nhint: "
                        + "username@gmail.com");
            } else if (password.length() < 8 ||
                       !password.matches(".*[A-Z].*") ||
                       !password.matches(".*\\d.*\\d.*\\d.*\\d.*") ||
                       !password.matches(".*[a-zA-Z].*[a-zA-Z].*")) {
                errorMessageLabel.setText("Password requirements not met. \nhint:"
                        + "should contains at least one capital letter+two letters + 4 digits");
            } else if (userPhoneNumber.length() != 10 || !userPhoneNumber.matches("05[0-9]{8}")) {
                errorMessageLabel.setText("Phone number must be 10 digits starting with 05.");
            } else if (isUsernameTaken(username)){
                errorMessageLabel.setText("Username is already taken. Please choose another one.");
            } 
            else {
                // Perform user registration logic using the FlowerApp instance
                boolean isRegistered = registerUser(username, password, firstName, lastName, userEmail, userPhoneNumber);

                if (isRegistered) {
                    // Navigate to the login scene after successful registration
                    primaryStage.setScene(logIn);
                } 
            }
        });

        btBack.setOnAction(e -> {
            primaryStage.setScene(logIn);
        });

      return signUpScene;
    }
    
    private boolean isUsernameTaken(String username) {
        // Simulating the check with a list of registered usernames
        return userDatabase.contains(username);
    }
    
    
    private boolean isValidEmail(String email) {
        // Add your email validation logic here
        // You can use a regular expression or a library for more sophisticated validation
        return email.matches("[a-z0-9._-]+@[a-z.-]+\\.[a-zA-Z]{3}");
    }
    
    public static void main(String[] args) {
        launch();
    }

}
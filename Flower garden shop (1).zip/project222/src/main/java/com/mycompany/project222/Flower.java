package com.mycompany.project222;

public class Flower {
    private String flowName;
    private double price;
    private String discription;
    private String season;
    private int flower_id;

    public Flower(String flowName, String discription, double price, String season, int flower_id) {
        this.flowName = flowName;
        this.price = price;
        this.discription = discription;
        this.flower_id = flower_id;
    }

    public String getDiscription() {
        return discription;
    }

    public void setDiscription(String discription) {
        this.discription = discription;
    }

    public String getSeason() {
        return season;
    }

    public void setSeason(String season) {
        this.season = season;
    }

    public int getFlower_id() {
        return flower_id;
    }

    public void setFlower_id(int flower_id) {
        this.flower_id = flower_id;
    }

    public Flower(String flowName, double price) {
        this.flowName = flowName;
        this.price = price;
    }

    
    
    public String getFlowName() {
        return flowName;
    }

    public void setFlowName(String flowName) {
        this.flowName = flowName;
    }


    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}


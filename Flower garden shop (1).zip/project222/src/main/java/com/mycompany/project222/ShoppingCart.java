package com.mycompany.project222;


import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table (name="ShoppingCart")
public class ShoppingCart {
    @Id
    @Column (name="cart_id")
    private int cart_id;
    @Column (name="flower_name")
    private String flower_name;
    @Column (name="price")
    private double price;
    @Column (name="quantity")
    private int quantity;
    

    public ShoppingCart(String flowerName, double price, int quantity) {
        this.flower_name = flowerName;
        this.price = price;
        this.quantity = quantity;
    }

    public String getFlowerName() {
        return flower_name;
    }

    public void setFlowerName(String flowerName) {
        this.flower_name = flowerName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getCart_id() {
        return cart_id;
    }

    public void setCart_id(int cart_id) {
        this.cart_id = cart_id;
    }
}


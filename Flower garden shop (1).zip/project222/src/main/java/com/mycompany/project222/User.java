package com.mycompany.project222;

public class User {
    private String username;
    private String password;
    private String fName;
    private String lastName;
    private String email;
    private String phoneNum;

    // Constructor
    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // Getter methods
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public User(String username, String password, String fName, String lastName, String email, String phoneNum) {
        this.username = username;
        this.password = password;
        this.fName = fName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNum = phoneNum;
    }
}


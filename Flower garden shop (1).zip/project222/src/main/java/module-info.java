module com.mycompany.project222 {
    requires javafx.controls;
    requires org.hibernate.orm.core;
    requires java.naming;
    requires java.persistence;
    
    opens com.mycompany.project222 to org.hibernate.orm.core;
    
    exports com.mycompany.project222;
}
